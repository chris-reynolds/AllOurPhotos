#import <Flutter/Flutter.h>

@interface FlutterGallaryPlugin : NSObject<FlutterPlugin>
@end
